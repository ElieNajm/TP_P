#ifndef GROUPE_H
#define GROUPE_H
#include<iostream>
using namespace std;
#include<list>
#include"multimedia.h"
#include<memory>


/**
 * @brief Groupe de médias, hérite d'une liste de pointeurs partagés vers des objets Multimedia.
 *
 * Permet de stocker plusieurs objets Multimedia (Photo, Video, Film, etc.)
 * dans une seule collection. L'héritage public de list<shared_ptr<Multimedia>>
 * permet d'utiliser directement toutes les méthodes de la liste (ajout, suppression, parcours, etc.).
 */
class Groupe :public list<shared_ptr<Multimedia>>
{
private:
    string nom{}; /**< Nom du groupe de médias */

public:
    Groupe();

    Groupe(const string& nom){
        this->nom = nom;
    }

    string getnom() const{ return nom;}


    /**
     * @brief Afficher les informations du groupe et de ses éléments multimédias.
     * @param cout Flux de sortie pour l'affichage.
     *
     * Affiche le nom du groupe, puis parcourt la liste des objets
     * Multimedia stockés dans le groupe et appelle leur méthode
     * d'affichage respective.
     */
    void affichage(ostream& cout) const{ //pas besoin d'override car elle n'herite pas de Multimedia
        cout<<" Nom du Groupe: "<<nom;
        for(auto it = this->begin(); it != this->end(); it++){
            (*it)->affichage(cout); //chaque objet va appeler sa propre methode d'affichage, ce n'est donc pas une recurrence
        }
    }

    ~Groupe(){
        cout<<"Groupe detruit"<<endl;
    }
};

#endif // GROUPE_H
