#ifndef PHOTO_H
#define PHOTO_H
#include<iostream>
#include"multimedia.h"
#include<string.h>
#include<string>
using namespace std;

class Photo : public Multimedia
{

private:
    double latitude{}; /**< Latitude associée à la photo */
    double longitude{}; /**< Longitude associée à la photo */

public:
    Photo(){
        latitude=0;
        longitude=0;
    }

    Photo(string nom, string nom_fichier, double latitude, double longitude):
        Multimedia(nom, nom_fichier)
    {
        this->latitude = latitude;
        this->longitude = longitude;
    }

    ~Photo(){
        cout<<"Photo detruite"<<endl;
    }
    double getlatitude() const{return latitude;};
    double getlongitude() const{return longitude;};
    void setlatitude(double latitude){this->latitude = latitude;};
    void setlongitude(double longitude){this->longitude = longitude;};

    /**
     * @brief Afficher les informations de la photo.
     * @param cout Flux de sortie pour l'affichage.
     *
     * Affiche le nom et le nom de fichier via la méthode de la classe
     * de base, puis ajoute la latitude et la longitude.
     */
    void affichage(ostream & cout) const override {
        Multimedia::affichage(cout);
        cout<<", la latitude est: "<<latitude<<", la longitude est: "<<longitude;
    }

    /**
     * @brief Ouvrir ou visualiser la photo.
     *
     * Lance l'application externe "imagej" pour afficher la photo
     * à partir du fichier associé.
     */
    void jouer() const override{
        string cmd = "imagej "+ getnom_fichier();
        system(cmd.c_str());
    }

    string getClassName() const override{
        return "Photo";
    }

    /**
     * @brief Écrire les informations de la photo dans un flux de sortie.
     * @param os Flux de sortie.
     *
     * Appelle la méthode de la classe de base pour écrire les attributs
     * communs, puis écrit la latitude et la longitude.
     */
    void write(ostream& os) const override{
        Multimedia::write(os);
        os<<latitude<<endl<<longitude<<endl;
    }

    /**
     * @brief Lire les informations de la photo depuis un flux d'entrée.
     * @param is Flux d'entrée.
     *
     * Appelle la méthode de la classe de base pour lire les attributs
     * communs, puis lit la latitude et la longitude depuis le flux.
     */
    void read(istream& is) override{
        Multimedia::read(is);
        string lat;
        getline(is, lat);
        latitude = stod(lat);
        string longi;
        getline(is, longi);
        longitude = stod(longi);
    }

};

#endif // PHOTO_H
