#ifndef DECLARATION_H
#define DECLARATION_H


class Declaration
{
public:
    Declaration();
};

#endif // DECLARATION_H
