#ifndef FILM_H
#define FILM_H
#include<iostream>
#include"video.h"
#include"multimedia.h"
#include<string.h>
#include<string>
using namespace std;

class Film : public Video
{

private:
    int* chapitre =  nullptr; /**< Tableau dynamique contenant la durée de chaque chapitre */
    int nbchap = 0; /**< Nombre de chapitres du film */


public:
    Film(){};

    ~Film(){
        delete[] chapitre;
        cout<<"Film detruit"<<endl;
    }

    Film( string nom, string nom_fichier, int duree, const int* chapitre, int nbchap):
        Video(nom, nom_fichier, duree)
    {
        //afin de copier le tableau donnee en input dans mon nouveau tableau
        if(nbchap > 0 && chapitre != nullptr){
            this->nbchap = nbchap;
            this->chapitre = new int[nbchap];
            for(int i = 0; i<nbchap; i++){this->chapitre[i] = chapitre[i];};
        }
    }


    /**
     * @brief Opérateur d'affectation.
     * @param other Film à copier.
     * @return Référence vers l'objet courant.
     *
     * Remplace le contenu de l'objet courant par celui de l'objet fourni.
     * Gère correctement le tableau dynamique et appelle l'opérateur de
     * la classe de base pour copier ses attributs.
     */
    Film& operator=(const Film &other){ //utiliser quand on veut remplacer le contenu d'un objet deja existant
        if(this != &other){ //pour verifier qu'il n' y a pas de "self-assignment"
             Video::operator=(other); //pour aussi copier les elements de la classe mere
             delete[] chapitre; //setfilm
             nbchap = other.nbchap;
             if(nbchap>0 && other.chapitre != nullptr){
                 chapitre = new int[nbchap];
                 for(int i=0; i<nbchap; i++){
                     chapitre[i]=other.chapitre[i];
                 }
             } else chapitre = nullptr;
        }
        return *this;
    }


    /**
     * @brief Constructeur par copie.
     * @param other Film à copier.
     *
     * Crée un nouvel objet Film en copiant les attributs de l'objet existant,
     * y compris le tableau de chapitres et les attributs de la classe de base.
     */
    Film(const Film &other) :
        Video(other) //pour copier les elements de la classe mere aussi
    { //utiliser quand on veut copier le contenu d'un objet dans un nouvel objet (objet qui n'existait pas au prealable)
        nbchap = other.nbchap; //setfilm
        if(nbchap>0 && other.chapitre != nullptr){
            chapitre = new int[nbchap];
            for(int i=0; i<nbchap; i++){
                chapitre[i] = other.chapitre[i];
            }
        } else chapitre = nullptr;
    }

    void setfilm(const int* chapitre, int nbchap){
        delete[] this->chapitre;
        if(nbchap > 0 && chapitre != nullptr){
            this->nbchap = nbchap;
            this->chapitre = new int[nbchap];
            for(int i = 0; i<nbchap; i++){this->chapitre[i] = chapitre[i];};
        } else {
            this->chapitre = nullptr;
            this->nbchap = 0;
        }
    }

    const int* getchapitre() const{return chapitre;}

    int getnbchap() const{return nbchap;}


    /**
     * @brief Afficher les informations du film.
     * @param cout Flux de sortie pour l'affichage.
     *
     * Affiche les informations de base via la classe Multimedia, puis affiche
     * la durée de chaque chapitre.
     */
    void affichage(ostream& cout) const override{
        Multimedia::affichage(cout);
        for(int i=0; i<nbchap; i++){
            cout<<", chapitre numero: "<<i+1<<", duree du chapitre: "<<(getchapitre())[i];
        }
    }

    string getClassName() const override{
        return "Film";
    }


    /**
     * @brief Écrire les informations du film dans un flux de sortie.
     * @param os Flux de sortie.
     *
     * Appelle la méthode de la classe Video pour écrire les attributs communs,
     * puis écrit le nombre de chapitres et la durée de chaque chapitre.
     */
    void write(ostream& os) const override{
        Video::write(os);
        os<<" nombre de chapitres: "<<nbchap;

        for(int i=0; i<nbchap; i++){
            os<<endl<<"chapitre numero: "<<i+1<<", duree du chapitre: "<<(getchapitre())[i];
        }
    }


    /**
     * @brief Lire les informations du film depuis un flux d'entrée.
     * @param is Flux d'entrée.
     *
     * Appelle la méthode de la classe Video pour lire les attributs communs,
     * puis lit le nombre de chapitres et le tableau des durées de chapitres.
     */
    void read(istream& is) override{
        Video::read(is);
        string nbc;
        getline(is, nbc);
        nbchap = stod(nbc);

        delete[] chapitre;
        chapitre = new int[nbchap];
        for(int i=0; i<nbchap; i++){
            is>>chapitre[i];
        }
    }

};

#endif // FILM_H
