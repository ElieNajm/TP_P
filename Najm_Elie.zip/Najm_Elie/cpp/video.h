#ifndef VIDEO_H
#define VIDEO_H
#include<iostream>
#include"multimedia.h"
#include<string.h>
#include<string>
using namespace std;

class Video : public Multimedia
{

private:
    int duree{}; /**< Durée de la vidéo en secondes */

public:
    Video(){duree = 0;};
    Video(string nom, string nom_fichier, int duree) :
        Multimedia(nom, nom_fichier)
    {
        this->duree = duree;

    }
    ~Video(){
        cout<<"Video detruite"<<endl;
    }
    int getduree() const{return duree;};
    void setduree(int duree){this->duree = duree;};

    /**
     * @brief Afficher les informations de la vidéo.
     * @param cout Flux de sortie pour l'affichage.
     *
     * Affiche le nom et le nom de fichier via la méthode de la classe
     * de base, puis ajoute la durée de la vidéo.
     */
    void affichage(ostream & cout) const override {
        Multimedia::affichage(cout);
        cout<<", la duree est: "<<duree;
    }

    /**
     * @brief Lire ou lancer la vidéo.
     *
     * Lance l'application externe "mpv" pour lire la vidéo
     * à partir du fichier associé.
     */
    void jouer() const override{
        string cmd = "mpv "+ getnom_fichier();
        system(cmd.c_str());
    }

    string getClassName() const override{
        return "Video";
    }

    /**
     * @brief Écrire les informations de la vidéo dans un flux de sortie.
     * @param os Flux de sortie.
     *
     * Appelle la méthode de la classe de base pour écrire les attributs
     * communs, puis écrit la durée de la vidéo.
     */
    void write(ostream& os) const override{
        Multimedia::write(os);
        os<<duree<<endl;
    }

    /**
     * @brief Lire les informations de la vidéo depuis un flux d'entrée.
     * @param is Flux d'entrée.
     *
     * Appelle la méthode de la classe de base pour lire les attributs
     * communs, puis lit la durée depuis le flux.
     */
    void read(istream& is) override{
        Multimedia::read(is);
        string dur;
        getline(is, dur);
        duree = stoi(dur);
    }

};

#endif // VIDEO_H
