#ifndef MULTIMEDIA_H
#define MULTIMEDIA_H
#include<iostream>
#include <string.h>
#include<string>
using namespace std;

/**
 * @class Multimedia
 * @brief Classe de base représentant un objet multimédia.
 *
 * Cette classe stocke le nom et le nom de fichier d'un objet multimédia
 * et fournit des méthodes virtuelles pour l'affichage, la lecture et la
 * lecture/écriture des objets.
 */

class Multimedia
{

private:
    string nom{};  /**< Nom de l'objet multimédia */
    string nom_fichier{};  /**< Nom de fichier associé à l'objet multimédia */

public:

    /**
     * @brief Constructeur par défaut.
     */
    Multimedia();

    /**
     * @brief Constructeur paramétré.
     * @param nom Nom de l'objet multimédia.
     * @param nom_fichier Nom de fichier associé.
     */
    Multimedia(string nom, string nom_fichier);

    /**
     * @brief Destructeur.
     */
    ~Multimedia();

    /**
     * @brief Récupérer le nom de l'objet multimédia.
     * @return Nom sous forme de chaîne.
     */
    string getnom() const;

    /**
     * @brief Récupérer le nom de fichier de l'objet multimédia.
     * @return Nom de fichier sous forme de chaîne.
     */
    string getnom_fichier() const;

    /**
     * @brief Modifier le nom de l'objet multimédia.
     * @param nom Nouveau nom.
     */
    void setnom(string nom);

    /**
     * @brief Modifier le nom de fichier de l'objet multimédia.
     * @param nom_fichier Nouveau nom de fichier.
     */
    void setnom_fichier(string nom_fichier);

    /**
     * @brief Afficher les informations de l'objet multimédia.
     * @param cout Flux de sortie pour l'affichage.
     *
     * Cette méthode affiche le nom et le nom de fichier de l'objet.
     * Elle peut être redéfinie dans les classes dérivées pour un affichage
     * plus détaillé.
     */
    virtual void affichage(ostream & cout) const;

    /**
     * @brief Jouer l'objet multimédia.
     *
     * Méthode purement virtuelle (abstraite) à implémenter dans les classes dérivées.
     * Définit la manière de lire l'objet (ex. audio, vidéo).
     */
    virtual void jouer() const = 0; //methode abstraite

    /**
     * @brief Récupérer le nom de la classe de l'objet multimédia.
     * @return Nom de la classe sous forme de chaîne.
     *
     * Peut être redéfini dans les classes dérivées pour retourner le type
     * spécifique de l'objet.
     */
    virtual string getClassName() const;

    /**
     * @brief Écrire l'objet multimédia dans un flux de sortie.
     * @param os Flux de sortie.
     *
     * Cette méthode sérialise les attributs de l'objet dans le flux fourni.
     * Peut être redéfinie dans les classes dérivées pour inclure des
     * attributs supplémentaires.
     */
    virtual void write(ostream& os) const;

    /**
     * @brief Lire l'objet multimédia depuis un flux d'entrée.
     * @param is Flux d'entrée.
     *
     * Cette méthode désérialise les attributs de l'objet depuis le flux fourni.
     * Peut être redéfinie dans les classes dérivées pour inclure des
     * attributs supplémentaires.
     */
    virtual void read(istream& is);
};

#endif // MULTIMEDIA_H
