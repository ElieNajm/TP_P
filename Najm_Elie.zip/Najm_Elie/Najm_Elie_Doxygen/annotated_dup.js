var annotated_dup =
[
    [ "javaSwing", null, [
      [ "Client", "classjava_swing_1_1_client.html", "classjava_swing_1_1_client" ],
      [ "FenetrePrincipale", "classjava_swing_1_1_fenetre_principale.html", "classjava_swing_1_1_fenetre_principale" ]
    ] ]
];