var class_photo =
[
    [ "affichage", "class_photo.html#aa16556483e323c3b186453408a3e3574", null ],
    [ "getClassName", "class_photo.html#a0811b00dc4a2c138efbeb600165d2744", null ],
    [ "jouer", "class_photo.html#a1a1d70a0906bda3edfff9339e47802f5", null ],
    [ "read", "class_photo.html#a1c78f904fd0179ecc980a485672dc074", null ],
    [ "write", "class_photo.html#a37bf6b9b0a15d5edc982a62ffbd6a4f5", null ]
];