var class_afterdoc___test =
[
    [ "EnumType", "class_afterdoc___test.html#adab0cd7ad3b4875e245ca8f6238a388a", [
      [ "EVal1", "class_afterdoc___test.html#adab0cd7ad3b4875e245ca8f6238a388aae054276790e35692ad0abe10c5b75da4", null ],
      [ "EVal2", "class_afterdoc___test.html#adab0cd7ad3b4875e245ca8f6238a388aac849f37624d8d2d68ca72c4a8df9cf99", null ]
    ] ],
    [ "member", "class_afterdoc___test.html#a57ba94e9039ee90a1b191ae0009a05dd", null ],
    [ "value", "class_afterdoc___test.html#a9287a08830e5cdfd9c732bb7932694a0", null ]
];