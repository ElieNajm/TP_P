var files_dup =
[
    [ "class.h", "class_8h_source.html", null ]
];