var files_dup =
[
    [ "docstring.py", "docstring_8py.html", "docstring_8py" ]
];