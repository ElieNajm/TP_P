var hierarchy =
[
    [ "A", "class_a.html", [
      [ "C", "class_c.html", null ],
      [ "D", "class_d.html", [
        [ "E", "class_e.html", null ]
      ] ]
    ] ],
    [ "B", "class_b.html", [
      [ "D", "class_d.html", null ]
    ] ]
];